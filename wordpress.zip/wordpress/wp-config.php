<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'wordpress' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '/5Flg]|Vt7+`ON)^YS[>jIg8CDY/KgBpFQA+dLaeXvN+}RJb>h<V[or5w2F|mC%]');
define('SECURE_AUTH_KEY',  '_~OK-8BnElO|<bI8IM&`2Q~pH-mo+aw_>0~!bz0`pWBAPgEH#s/A!H6BVy^|r%j9');
define('LOGGED_IN_KEY',    'SVvTM.=f FPc5rz[@($$GElv,-ztmnGzHwbM+>{.H8!u}`ggpy+<-{ER/|x|+Zwm');
define('NONCE_KEY',        'l3M[YMu]X2 %8F$Xmx)mAClWncg@k;-@mfq$,6Lru:/F[%nDeBFWKQ8xPfcKh/*s');
define('AUTH_SALT',        'SeR5PBRILmp,q4{})fe|XLh]yK@d)0cX0iV230HCh$+y <-Az!jN6!23;~rwG|+^');
define('SECURE_AUTH_SALT', 'MCJ!Xqg|t17.a7.2(vIfMVCML*+mdOY^X]/~N&h7@^mQ~n]<x]AK-y;YL)X{nxz/');
define('LOGGED_IN_SALT',   'G*SMM44gQ!C`!KH}QzS?Mq!k*7v;H}N>!XxTcioJ4jgT5+du,RvNZbQUKVbZU?js');
define('NONCE_SALT',       '[24a@rTsmJj?lBO@kS!i|boL%,f]y3gXa8P:u#C!fovL(|1xhSNju.b+&lo@N-8{');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


define( 'JETPACK_DEV_DEBUG', True );
define( 'WP_DEBUG', True );
define( 'FORCE_SSL_ADMIN', False );
define( 'SAVEQUERIES', False );

// Addtional PHP code in the wp-config.php
// These lines are inserted by VCCW.
// You can place addtional PHP code here!


/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
